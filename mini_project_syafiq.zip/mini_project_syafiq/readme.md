# How To Use

1. Clone this repository
2. Run `npm install` in terminal for install
3. Run `npm run dev` in terminal for running project
4. Install VS CODE Extension Live Server
5. Right click on index.html then open with live server

